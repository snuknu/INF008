package br.edu.ifba.ads.poo.trabalho.entidades;

public interface Trajetoria {

	public double getDistancia(Coordenada origem, Coordenada destino);
	
}
